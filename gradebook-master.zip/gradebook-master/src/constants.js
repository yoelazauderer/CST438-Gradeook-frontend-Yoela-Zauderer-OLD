export const SERVER_URL = 'http://localhost:8081';
